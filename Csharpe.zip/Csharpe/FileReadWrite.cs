using System;
using System.IO;
using System.Xml;

class FileReadWrite
{
    string outputPath = "Output.txt";

    public static void Main(string[] args)
    {
       
            string inputJson = "input.json";
            string inputXml = "input.xml";
            string inputTxt = "input.txt";

            FileReadWrite instance = new FileReadWrite();
            
            instance.WriteJson(inputJson);
            instance.WriteXml(inputXml);
            instance.WriteTxt(inputTxt);

            //here i create object of this class to access the non static methods .
        
       
    }

    void WriteXml(string inputXml)
    {
        try{
             if (File.Exists(inputXml))
             {
               XmlDocument xmlDoc = new XmlDocument();
               xmlDoc.Load(inputXml);

               using (StreamWriter writer = new StreamWriter(outputPath, true))
               {
                  writer.WriteLine("XML Data: (" + DateTime.Now + ")");
                  writer.WriteLine(xmlDoc.OuterXml);
               }
            }
        }
        catch (Exception e)
        {
            using (StreamWriter writer = new StreamWriter("Output.txt", true))
            {
                writer.WriteLine("Error: (" + DateTime.Now + ") " + e.Message);
            }
        }
       
    }

    void WriteJson(string inputJson)
    {
        try{
            if (File.Exists(inputJson))
            {
              string jsonData = File.ReadAllText(inputJson);

              using (StreamWriter writer = new StreamWriter(outputPath, true))
               {
                 writer.WriteLine("JSON Data: (" + DateTime.Now + ")");
                 writer.WriteLine(jsonData);
               }
            }
        }


        catch (Exception e)
        {
            using (StreamWriter writer = new StreamWriter("Output.txt", true))
            {
                writer.WriteLine("Error: (" + DateTime.Now + ") " + e.Message);
            }
        }
    }

    void WriteTxt(string inputTxt)
    {
       try{
         if (File.Exists(inputTxt))
         {
            string txt = File.ReadAllText(inputTxt);

            using (StreamWriter writer = new StreamWriter(outputPath, true))
            {
                writer.WriteLine("TXT Data: (" + DateTime.Now + ")");
                writer.WriteLine(txt);
            }
         }
       }


       catch (Exception e)
        {
            using (StreamWriter writer = new StreamWriter("Output.txt", true))
            {
                writer.WriteLine("Error: (" + DateTime.Now + ") " + e.Message);
            }
        }

        
    }
}
